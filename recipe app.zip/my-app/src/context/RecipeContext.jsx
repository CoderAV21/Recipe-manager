import { createContext, useContext, useState, useEffect } from "react";

const RecipeContext = createContext();

const initialRecipes = [
  {
    id: 1,
    title: "Margherita Pizza",
    category: "Italian",
    cookTime: "40 min",
    servings: 4,
    difficulty: "Medium",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=500&q=80",
    description:
      "A Neapolitan-style pizza with a blistered crust, tangy tomato sauce, fresh mozzarella and basil.",
    ingredients: [
      "500g pizza dough",
      "200g San Marzano tomatoes",
      "200g fresh mozzarella",
      "Fresh basil leaves",
      "Olive oil",
      "Salt",
    ],
    steps: [
      "Preheat oven to its highest setting with a pizza stone inside.",
      "Crush tomatoes with salt to make a quick sauce.",
      "Stretch dough into a thin round on a floured surface.",
      "Spread sauce and tear mozzarella over the top.",
      "Bake 8-10 mins until the crust is charred in spots.",
      "Finish with basil and a drizzle of olive oil.",
    ],
    isFavorite: false,
  },
  {
    id: 2,
    title: "Paneer Tikka Masala",
    category: "Indian",
    cookTime: "40 min",
    servings: 4,
    difficulty: "Medium",
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=500&q=80",
    description:
      "Smoky grilled paneer cubes simmered in a rich, spiced tomato and cashew gravy.",
    ingredients: [
      "400g paneer, cubed",
      "1 cup thick yogurt",
      "400g tomato puree",
      "2 tbsp cashew paste",
      "1 large onion",
      "Garam masala, turmeric, chili powder",
      "Ginger-garlic paste",
      "Kasuri methi",
    ],
    steps: [
      "Marinate paneer in yogurt and spices for 30 minutes.",
      "Grill or pan-sear paneer until lightly charred.",
      "Sauté onion, ginger and garlic until golden.",
      "Add tomato puree and spices; cook until oil separates.",
      "Stir in cashew paste and a splash of water; simmer 10 mins.",
      "Add paneer and kasuri methi. Serve with naan or rice.",
    ],
    isFavorite: true,
  },
  {
    id: 3,
    title: "Blueberry Pancakes",
    category: "Breakfast",
    cookTime: "20 min",
    servings: 3,
    difficulty: "Easy",
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=500&q=80",
    description:
      "Fluffy buttermilk pancakes studded with juicy blueberries and finished with maple syrup.",
    ingredients: [
      "1.5 cups all-purpose flour",
      "1 cup buttermilk",
      "1 egg",
      "2 tbsp sugar",
      "1 tsp baking powder",
      "1 cup blueberries",
      "Butter for the pan",
      "Maple syrup",
    ],
    steps: [
      "Whisk dry ingredients together in a bowl.",
      "Mix buttermilk, egg and melted butter, then fold into the dry mix.",
      "Gently fold in the blueberries.",
      "Cook ladles of batter on a buttered pan until bubbles form.",
      "Flip and cook until golden.",
      "Stack and serve with maple syrup.",
    ],
    isFavorite: false,
  },
  {
    id: 4,
    title: "Classic Tiramisu",
    category: "Dessert",
    cookTime: "30 min",
    servings: 6,
    difficulty: "Hard",
    image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=500&q=80",
    description:
      "Layers of espresso-soaked ladyfingers and whipped mascarpone cream dusted with cocoa.",
    ingredients: [
      "250g mascarpone",
      "3 egg yolks",
      "75g sugar",
      "200ml strong espresso, cooled",
      "200g ladyfingers",
      "150ml heavy cream",
      "Cocoa powder",
    ],
    steps: [
      "Whisk yolks and sugar until pale and thick.",
      "Fold in mascarpone, then softly whipped cream.",
      "Quickly dip ladyfingers in espresso.",
      "Layer biscuits and cream in a dish; repeat.",
      "Chill for at least 6 hours.",
      "Dust generously with cocoa before serving.",
    ],
    isFavorite: true,
  },
  {
    id: 5,
    title: "Quinoa Power Bowl",
    category: "Salad",
    cookTime: "25 min",
    servings: 2,
    difficulty: "Easy",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80",
    description:
      "A hearty bowl of quinoa, roasted chickpeas, avocado and greens with a lemon-tahini dressing.",
    ingredients: [
      "1 cup quinoa",
      "1 can chickpeas",
      "1 avocado",
      "2 cups baby spinach",
      "1 cup cherry tomatoes",
      "2 tbsp tahini",
      "1 lemon",
      "Olive oil",
    ],
    steps: [
      "Cook quinoa according to package directions.",
      "Roast chickpeas with olive oil and paprika until crisp.",
      "Whisk tahini, lemon juice and water into a dressing.",
      "Arrange quinoa, spinach, tomatoes and avocado in bowls.",
      "Top with chickpeas and drizzle with dressing.",
    ],
    isFavorite: false,
  },
  {
    id: 6,
    title: "Chicken Fajitas",
    category: "Mexican",
    cookTime: "30 min",
    servings: 4,
    difficulty: "Medium",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=500&q=80",
    description:
      "Sizzling strips of spiced chicken with charred peppers and onions, wrapped in warm tortillas.",
    ingredients: [
      "600g chicken breast, sliced",
      "3 bell peppers",
      "1 red onion",
      "Flour tortillas",
      "Cumin, smoked paprika, chili powder",
      "Lime",
      "Sour cream",
      "Fresh cilantro",
    ],
    steps: [
      "Toss chicken with spices, lime juice and oil.",
      "Sear chicken in a very hot skillet until cooked through.",
      "Cook peppers and onion until charred at the edges.",
      "Warm tortillas on a dry pan.",
      "Fill with chicken and vegetables.",
      "Top with sour cream and cilantro.",
    ],
    isFavorite: false,
  },
];

const STORAGE_KEY = "recipevault_recipes_v2";

export function RecipeProvider({ children }) {
  const [recipes, setRecipes] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : initialRecipes;
    } catch {
      return initialRecipes;
    }
  });

  // Sync to localStorage whenever recipes change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(recipes));
    } catch {
      // localStorage unavailable (e.g. private mode quota)
    }
  }, [recipes]);

  const addRecipe = (newRecipe) => {
    const recipe = {
      ...newRecipe,
      id: Date.now(),
      isFavorite: false,
      image:
        newRecipe.image ||
        "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=500&q=80",
    };
    setRecipes((prev) => [recipe, ...prev]);
  };

  const deleteRecipe = (id) => {
    setRecipes((prev) => prev.filter((r) => r.id !== id));
  };

  const toggleFavorite = (id) => {
    setRecipes((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isFavorite: !r.isFavorite } : r))
    );
  };

  const favorites = recipes.filter((r) => r.isFavorite);

  return (
    <RecipeContext.Provider
      value={{ recipes, favorites, addRecipe, deleteRecipe, toggleFavorite }}
    >
      {children}
    </RecipeContext.Provider>
  );
}

export function useRecipes() {
  return useContext(RecipeContext);
}
